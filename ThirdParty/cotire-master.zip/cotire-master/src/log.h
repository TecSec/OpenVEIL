// cotire example project

#include <string>

namespace logging {

void error(const std::string& msg);
void info(const std::string& msg);

}
